MYSQL2_VERSION = '>= 0.3'
RAILS_VERSION = '~> 3.2.0'

eval File.read(File.expand_path('../../Gemfile', __FILE__))
